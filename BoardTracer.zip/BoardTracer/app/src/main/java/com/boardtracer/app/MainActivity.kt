package com.boardtracer.app

import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.max

class MainActivity : AppCompatActivity() {

    companion object {
        const val DEFAULT_MODEL = "claude-sonnet-5-5"
        const val MAX_EDGE = 1568
    }

    private lateinit var overlay: OverlayView
    private lateinit var notes: TextView
    private lateinit var progress: ProgressBar
    private lateinit var btnAnalyze: Button
    private var bitmap: Bitmap? = null
    private var manualCounter = 1
    private val modeButtons = HashMap<Int, Mode>()
    private val executor = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("prefs", Context.MODE_PRIVATE) }
    private val photoFile by lazy { File(cacheDir, "capture.jpg") }

    private val takePicture =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
            if (ok) loadFile(photoFile)
        }

    private val pickImage =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                try {
                    val f = File(cacheDir, "gallery.jpg")
                    contentResolver.openInputStream(uri)?.use { input ->
                        f.outputStream().use { out -> input.copyTo(out) }
                    }
                    loadFile(f)
                } catch (e: Exception) {
                    toast("تعذر فتح الصورة: " + e.message)
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        overlay = findViewById(R.id.overlay)
        notes = findViewById(R.id.notes)
        progress = findViewById(R.id.progress)
        btnAnalyze = findViewById(R.id.btnAnalyze)

        findViewById<Button>(R.id.btnCamera).setOnClickListener {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", photoFile)
            takePicture.launch(uri)
        }
        findViewById<Button>(R.id.btnGallery).setOnClickListener { pickImage.launch("image/*") }
        btnAnalyze.setOnClickListener { analyze() }
        findViewById<Button>(R.id.btnSettings).setOnClickListener { showSettings() }

        bindCheck(R.id.chkComps) { overlay.showComps = it }
        bindCheck(R.id.chkPower) { overlay.showPower = it }
        bindCheck(R.id.chkGround) { overlay.showGround = it }
        bindCheck(R.id.chkSignal) { overlay.showSignal = it }

        overlay.onCompTap = { c ->
            notes.text = c.name + " (" + c.type + ")\n" + c.desc
        }

        // أدوات الرسم اليدوي (تشتغل بدون إنترنت أو مفتاح API)
        modeButtons[R.id.btnView] = Mode.VIEW
        modeButtons[R.id.btnBox] = Mode.BOX
        modeButtons[R.id.btnPower] = Mode.POWER
        modeButtons[R.id.btnGround] = Mode.GROUND
        modeButtons[R.id.btnSignal] = Mode.SIGNAL
        for ((id, mode) in modeButtons) {
            findViewById<Button>(id).setOnClickListener { setMode(mode) }
        }
        setMode(Mode.VIEW)

        findViewById<Button>(R.id.btnUndo).setOnClickListener {
            if (!overlay.undoManual()) toast("مفيش حاجة يدوية للتراجع عنها")
        }
        findViewById<Button>(R.id.btnSave).setOnClickListener { saveResult() }

        overlay.onBoxDrawn = { x, y, w, h ->
            promptText("اسم القطعة", "مثال: IC1 / كاب 1000uF") { name ->
                val id = "M" + (manualCounter++)
                overlay.addComp(
                    Comp(id, name.ifEmpty { "قطعة" }, "manual", x, y, w, h, "أضفتها يدويًا")
                )
            }
        }
        overlay.onPathDrawn = { kind, pts ->
            promptText("اسم المسار أو الجهد (اختياري)", "مثال: 12V") { label ->
                overlay.addConn(Conn("", "", kind, label, true, pts))
            }
        }
    }

    private fun setMode(mode: Mode) {
        overlay.mode = mode
        for ((id, md) in modeButtons) {
            findViewById<Button>(id).alpha = if (md == mode) 1f else 0.55f
        }
        notes.text = when (mode) {
            Mode.VIEW -> "وضع التحريك: اسحب للتحريك وبإصبعين للتكبير."
            Mode.BOX -> "ارسم مستطيل بإصبعك حوالين القطعة وهتسميها."
            Mode.POWER -> "ارسم بإصبعك مسار الكهرباء من أوله لآخره."
            Mode.GROUND -> "ارسم بإصبعك مسار الأرضي."
            Mode.SIGNAL -> "ارسم بإصبعك مسار الإشارة."
        }
    }

    private fun promptText(title: String, hint: String, onOk: (String) -> Unit) {
        val et = EditText(this).apply {
            this.hint = hint
            setSingleLine(true)
        }
        val box = LinearLayout(this).apply { setPadding(48, 24, 48, 0) }
        box.addView(et, LinearLayout.LayoutParams(-1, -2))
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("تم") { _, _ -> onOk(et.text.toString().trim()) }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun saveResult() {
        val out = overlay.render()
        if (out == null) {
            toast("مفيش صورة لحفظها")
            return
        }
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, "BoardTracer_" + System.currentTimeMillis() + ".png")
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/BoardTracer")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                if (uri == null) {
                    toast("تعذر الحفظ")
                    return
                }
                contentResolver.openOutputStream(uri)?.use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
                toast("اتحفظت في المعرض: Pictures/BoardTracer")
            } else {
                val f = File(cacheDir, "result.png")
                f.outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
                val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "image/png"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(Intent.createChooser(send, "حفظ / مشاركة النتيجة"))
            }
        } catch (e: Exception) {
            toast("خطأ في الحفظ: " + e.message)
        }
    }

    private fun bindCheck(id: Int, set: (Boolean) -> Unit) {
        findViewById<CheckBox>(id).setOnCheckedChangeListener { _, checked ->
            set(checked)
            overlay.invalidate()
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun loadFile(f: File) {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, bounds)
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > MAX_EDGE * 2) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp = BitmapFactory.decodeFile(f.path, opts) ?: throw IllegalStateException("فشل قراءة الصورة")

            val orientation = ExifInterface(f.path)
                .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            val rot = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            val scale = MAX_EDGE.toFloat() / max(bmp.width, bmp.height)
            if (rot != 0f || scale < 1f) {
                val mx = Matrix()
                if (rot != 0f) mx.postRotate(rot)
                if (scale < 1f) mx.postScale(scale, scale)
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, mx, true)
            }
            bitmap = bmp
            overlay.bitmap = bmp
            notes.text = "تم تحميل الصورة. اضغط تحليل."
        } catch (e: Exception) {
            toast("خطأ في تحميل الصورة: " + e.message)
        }
    }

    private fun setBusy(b: Boolean) {
        progress.visibility = if (b) View.VISIBLE else View.GONE
        btnAnalyze.isEnabled = !b
    }

    private fun analyze() {
        val bmp = bitmap
        if (bmp == null) {
            toast("صوّر أو اختر صورة أولاً")
            return
        }
        val key = (prefs.getString("api_key", "") ?: "").trim()
        if (key.isEmpty()) {
            toast("ادخل مفتاح API أولاً")
            showSettings()
            return
        }
        val model = (prefs.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL).trim()
        setBusy(true)
        notes.text = "جاري التحليل... قد يستغرق دقيقة."

        executor.execute {
            try {
                val baos = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, 90, baos)
                val raw = ClaudeClient.analyze(key, model, baos.toByteArray())
                val a = Parser.parse(raw)
                runOnUiThread {
                    overlay.setResult(a)
                    val head = "تم العثور على " + a.comps.size + " قطعة و " + a.conns.size +
                        " توصيلة.\nالخط المتقطع = تقدير غير مؤكد. اضغط على أي قطعة لشرحها.\n\n"
                    notes.text = head + a.notes
                    setBusy(false)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    notes.text = "خطأ: " + e.message
                    setBusy(false)
                }
            }
        }
    }

    private fun showSettings() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
        }
        val keyEt = EditText(this).apply {
            hint = "Anthropic API Key"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("api_key", ""))
        }
        val modelEt = EditText(this).apply {
            hint = "Model"
            setText(prefs.getString("model", DEFAULT_MODEL))
        }
        box.addView(keyEt)
        box.addView(modelEt)
        AlertDialog.Builder(this)
            .setTitle("الإعدادات")
            .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                prefs.edit()
                    .putString("api_key", keyEt.text.toString().trim())
                    .putString("model", modelEt.text.toString().trim().ifEmpty { DEFAULT_MODEL })
                    .apply()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }
}
