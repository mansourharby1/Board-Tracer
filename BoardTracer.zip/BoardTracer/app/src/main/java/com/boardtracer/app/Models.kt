package com.boardtracer.app

import android.graphics.PointF
import org.json.JSONArray
import org.json.JSONObject

data class Comp(
    val id: String,
    val name: String,
    val type: String,
    val x: Float,
    val y: Float,
    val w: Float,
    val h: Float,
    val desc: String
)

data class Conn(
    val from: String,
    val to: String,
    val kind: String,
    val label: String,
    val certain: Boolean,
    val pts: List<PointF>
)

data class Analysis(
    val comps: List<Comp>,
    val conns: List<Conn>,
    val notes: String
)

object Parser {
    private fun c(v: Double): Float = v.toFloat().coerceIn(0f, 1f)

    fun parse(text: String): Analysis {
        val s = text.indexOf('{')
        val e = text.lastIndexOf('}')
        if (s < 0 || e <= s) throw IllegalArgumentException("الرد لا يحتوي على JSON صالح")
        val root = JSONObject(text.substring(s, e + 1))

        val comps = ArrayList<Comp>()
        val ca: JSONArray = root.optJSONArray("components") ?: JSONArray()
        for (i in 0 until ca.length()) {
            val o = ca.getJSONObject(i)
            val b = o.optJSONArray("box") ?: continue
            if (b.length() < 4) continue
            comps.add(
                Comp(
                    id = o.optString("id", "c$i"),
                    name = o.optString("name", "?"),
                    type = o.optString("type", ""),
                    x = c(b.getDouble(0)), y = c(b.getDouble(1)),
                    w = c(b.getDouble(2)), h = c(b.getDouble(3)),
                    desc = o.optString("desc", "")
                )
            )
        }

        val conns = ArrayList<Conn>()
        val na: JSONArray = root.optJSONArray("connections") ?: JSONArray()
        for (i in 0 until na.length()) {
            val o = na.getJSONObject(i)
            val pts = ArrayList<PointF>()
            val pa = o.optJSONArray("path")
            if (pa != null) {
                for (j in 0 until pa.length()) {
                    val p = pa.optJSONArray(j) ?: continue
                    if (p.length() >= 2) pts.add(PointF(c(p.getDouble(0)), c(p.getDouble(1))))
                }
            }
            conns.add(
                Conn(
                    from = o.optString("from", ""),
                    to = o.optString("to", ""),
                    kind = o.optString("kind", "signal").lowercase(),
                    label = o.optString("label", ""),
                    certain = o.optBoolean("certain", true),
                    pts = pts
                )
            )
        }
        return Analysis(comps, conns, root.optString("notes", ""))
    }
}
