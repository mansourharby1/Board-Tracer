package com.boardtracer.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

enum class Mode { VIEW, BOX, POWER, GROUND, SIGNAL }

class OverlayView @JvmOverloads constructor(
    ctx: Context,
    attrs: AttributeSet? = null
) : View(ctx, attrs) {

    var bitmap: Bitmap? = null
        set(v) {
            field = v
            analysis = null
            manual.clear()
            cancelDraft()
            fit()
            invalidate()
        }

    var analysis: Analysis? = null
        set(v) {
            field = v
            invalidate()
        }

    var showComps = true
    var showPower = true
    var showGround = true
    var showSignal = true
    var mode = Mode.VIEW
        set(v) {
            field = v
            cancelDraft()
            invalidate()
        }

    var onCompTap: ((Comp) -> Unit)? = null
    var onBoxDrawn: ((Float, Float, Float, Float) -> Unit)? = null
    var onPathDrawn: ((String, List<PointF>) -> Unit)? = null

    private val manual = ArrayList<Char>()
    private var drawing = false
    private var draftBox: RectF? = null
    private var draftStart: PointF? = null
    private val draftPts = ArrayList<PointF>()

    private val m = Matrix()
    private val inv = Matrix()
    private val dp = resources.displayMetrics.density

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(190, 0, 0, 0)
    }

    private val scaleDet = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            m.postScale(d.scaleFactor, d.scaleFactor, d.focusX, d.focusY)
            invalidate()
            return true
        }
    })

    private val gestDet = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
            if (!scaleDet.isInProgress) {
                m.postTranslate(-dx, -dy)
                invalidate()
            }
            return true
        }

        override fun onSingleTapUp(e: MotionEvent): Boolean {
            handleTap(e.x, e.y)
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            fit()
            invalidate()
            return true
        }
    })

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        fit()
    }

    private fun fit() {
        val b = bitmap ?: return
        if (width == 0 || height == 0) return
        val s = min(width.toFloat() / b.width, height.toFloat() / b.height)
        m.reset()
        m.postScale(s, s)
        m.postTranslate((width - b.width * s) / 2f, (height - b.height * s) / 2f)
    }

    // ---------- manual editing API ----------

    fun setResult(a: Analysis) {
        manual.clear()
        analysis = a
    }

    fun addComp(c: Comp) {
        val a = analysis ?: Analysis(emptyList(), emptyList(), "")
        analysis = Analysis(a.comps + c, a.conns, a.notes)
        manual.add('c')
    }

    fun addConn(cn: Conn) {
        val a = analysis ?: Analysis(emptyList(), emptyList(), "")
        analysis = Analysis(a.comps, a.conns + cn, a.notes)
        manual.add('n')
    }

    fun undoManual(): Boolean {
        if (manual.isEmpty()) return false
        val a = analysis ?: return false
        val last = manual.removeAt(manual.size - 1)
        analysis = if (last == 'c') {
            Analysis(a.comps.dropLast(1), a.conns, a.notes)
        } else {
            Analysis(a.comps, a.conns.dropLast(1), a.notes)
        }
        return true
    }

    fun render(): Bitmap? {
        val b = bitmap ?: return null
        val out = b.copy(Bitmap.Config.ARGB_8888, true)
        val c = Canvas(out)
        val u = max(b.width, b.height) / 900f
        drawContent(c, b.width.toFloat(), b.height.toFloat(), u, false)
        return out
    }

    // ---------- touch ----------

    private fun cancelDraft() {
        drawing = false
        draftBox = null
        draftStart = null
        draftPts.clear()
    }

    private fun toNorm(x: Float, y: Float): PointF? {
        val b = bitmap ?: return null
        if (!m.invert(inv)) return null
        val p = floatArrayOf(x, y)
        inv.mapPoints(p)
        return PointF((p[0] / b.width).coerceIn(0f, 1f), (p[1] / b.height).coerceIn(0f, 1f))
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDet.onTouchEvent(event)
        if (mode == Mode.VIEW) {
            gestDet.onTouchEvent(event)
            return true
        }
        if (scaleDet.isInProgress || event.pointerCount > 1) {
            cancelDraft()
            invalidate()
            return true
        }
        if (bitmap == null) return true

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val p = toNorm(event.x, event.y) ?: return true
                drawing = true
                draftStart = p
                draftPts.clear()
                draftPts.add(p)
                draftBox = null
            }
            MotionEvent.ACTION_MOVE -> {
                if (drawing) {
                    val p = toNorm(event.x, event.y) ?: return true
                    if (mode == Mode.BOX) {
                        val s = draftStart!!
                        draftBox = RectF(min(s.x, p.x), min(s.y, p.y), max(s.x, p.x), max(s.y, p.y))
                    } else {
                        val last = draftPts.last()
                        if (abs(p.x - last.x) + abs(p.y - last.y) > 0.006f) draftPts.add(p)
                    }
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP -> {
                if (drawing) {
                    val p = toNorm(event.x, event.y)
                    if (mode == Mode.BOX) {
                        val r = draftBox
                        if (r != null && r.width() > 0.01f && r.height() > 0.01f) {
                            onBoxDrawn?.invoke(r.left, r.top, r.width(), r.height())
                        }
                    } else {
                        if (p != null) draftPts.add(p)
                        if (draftPts.size >= 2) {
                            val kind = when (mode) {
                                Mode.POWER -> "power"
                                Mode.GROUND -> "ground"
                                else -> "signal"
                            }
                            onPathDrawn?.invoke(kind, ArrayList(draftPts))
                        }
                    }
                    cancelDraft()
                    invalidate()
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                cancelDraft()
                invalidate()
            }
        }
        return true
    }

    private fun handleTap(x: Float, y: Float) {
        val a = analysis ?: return
        val p = toNorm(x, y) ?: return
        val hit = a.comps
            .filter { p.x >= it.x && p.x <= it.x + it.w && p.y >= it.y && p.y <= it.y + it.h }
            .minByOrNull { it.w * it.h }
        if (hit != null) onCompTap?.invoke(hit)
    }

    // ---------- drawing ----------

    private fun kindColor(kind: String): Int = when (kind) {
        "power" -> Color.rgb(255, 82, 82)
        "ground" -> Color.rgb(176, 190, 197)
        else -> Color.rgb(66, 165, 245)
    }

    private fun kindVisible(kind: String): Boolean = when (kind) {
        "power" -> showPower
        "ground" -> showGround
        else -> showSignal
    }

    override fun onDraw(canvas: Canvas) {
        val bmp = bitmap ?: return
        canvas.save()
        canvas.concat(m)
        canvas.drawBitmap(bmp, 0f, 0f, null)
        val v = FloatArray(9)
        m.getValues(v)
        val u = dp / v[Matrix.MSCALE_X]
        drawContent(canvas, bmp.width.toFloat(), bmp.height.toFloat(), u, true)
        canvas.restore()
    }

    private fun drawContent(canvas: Canvas, bw: Float, bh: Float, u: Float, withDraft: Boolean) {
        val a = analysis
        if (a != null) {
            val byId = a.comps.associateBy { it.id }

            for (cn in a.conns) {
                if (!kindVisible(cn.kind)) continue
                val pts = ArrayList<PointF>()
                byId[cn.from]?.let { pts.add(PointF((it.x + it.w / 2) * bw, (it.y + it.h / 2) * bh)) }
                for (p in cn.pts) pts.add(PointF(p.x * bw, p.y * bh))
                byId[cn.to]?.let { pts.add(PointF((it.x + it.w / 2) * bw, (it.y + it.h / 2) * bh)) }
                if (pts.size < 2) continue

                val col = kindColor(cn.kind)
                linePaint.color = col
                linePaint.strokeWidth = (if (cn.kind == "power") 3.5f else 2.5f) * u
                linePaint.pathEffect =
                    if (cn.certain) null else DashPathEffect(floatArrayOf(10f * u, 8f * u), 0f)
                val path = Path()
                path.moveTo(pts[0].x, pts[0].y)
                for (i in 1 until pts.size) path.lineTo(pts[i].x, pts[i].y)
                canvas.drawPath(path, linePaint)
                linePaint.pathEffect = null

                if (cn.kind == "power") {
                    val p1 = pts[pts.size - 2]
                    val p2 = pts[pts.size - 1]
                    val ang = atan2(p2.y - p1.y, p2.x - p1.x)
                    val len = 11f * u
                    val ar = Path()
                    ar.moveTo(p2.x, p2.y)
                    ar.lineTo(p2.x - len * cos(ang - 0.45f), p2.y - len * sin(ang - 0.45f))
                    ar.lineTo(p2.x - len * cos(ang + 0.45f), p2.y - len * sin(ang + 0.45f))
                    ar.close()
                    fillPaint.color = col
                    canvas.drawPath(ar, fillPaint)
                }

                if (cn.label.isNotEmpty()) {
                    val mid = pts[pts.size / 2]
                    textPaint.textSize = 11f * u
                    val tw = textPaint.measureText(cn.label)
                    val r = RectF(mid.x - 2 * u, mid.y - 13 * u, mid.x + tw + 4 * u, mid.y + 2 * u)
                    canvas.drawRect(r, bgPaint)
                    textPaint.color = col
                    canvas.drawText(cn.label, mid.x + u, mid.y - 2 * u, textPaint)
                    textPaint.color = Color.WHITE
                }
            }

            if (showComps) {
                for (c in a.comps) {
                    val r = RectF(c.x * bw, c.y * bh, (c.x + c.w) * bw, (c.y + c.h) * bh)
                    linePaint.color = Color.rgb(67, 160, 71)
                    linePaint.strokeWidth = 2f * u
                    linePaint.pathEffect = null
                    canvas.drawRect(r, linePaint)

                    textPaint.textSize = 11f * u
                    textPaint.color = Color.WHITE
                    val tw = textPaint.measureText(c.name)
                    val bgR = RectF(r.left, r.top - 14 * u, r.left + tw + 6 * u, r.top)
                    canvas.drawRect(bgR, bgPaint)
                    canvas.drawText(c.name, r.left + 3 * u, r.top - 3 * u, textPaint)
                }
            }
        }

        if (withDraft) {
            val box = draftBox
            if (box != null) {
                linePaint.color = Color.YELLOW
                linePaint.strokeWidth = 2f * u
                linePaint.pathEffect = DashPathEffect(floatArrayOf(8f * u, 6f * u), 0f)
                canvas.drawRect(box.left * bw, box.top * bh, box.right * bw, box.bottom * bh, linePaint)
                linePaint.pathEffect = null
            }
            if (draftPts.size >= 2) {
                val kind = when (mode) {
                    Mode.POWER -> "power"
                    Mode.GROUND -> "ground"
                    else -> "signal"
                }
                linePaint.color = kindColor(kind)
                linePaint.strokeWidth = 3f * u
                linePaint.pathEffect = null
                val path = Path()
                path.moveTo(draftPts[0].x * bw, draftPts[0].y * bh)
                for (i in 1 until draftPts.size) path.lineTo(draftPts[i].x * bw, draftPts[i].y * bh)
                canvas.drawPath(path, linePaint)
            }
        }
    }
}
