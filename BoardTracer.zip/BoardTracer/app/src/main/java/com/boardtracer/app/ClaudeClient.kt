package com.boardtracer.app

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

object ClaudeClient {

    private const val PROMPT = """
أنت مهندس إلكترونيات خبير في صيانة بوردات الريسيفر والشاشات والريموتات ومصادر الطاقة.
حلّل الصورة المرفقة (بوردة إلكترونية أو شاشة) وأخرج لي:
1) القطع الظاهرة (ICs، مكثفات، ملفات، ترانزستورات، دايودات، مقاومات كبيرة، كونكترات، منظمات جهد، كريستالة، فيوز... إلخ).
2) مسارات الكهرباء: من مدخل الطاقة (adapter / jack / PSU) إلى منظمات الجهد ثم القطع التي تغذيها، مع تقدير الجهد إن أمكن.
3) مسارات الأرضي (ground) الرئيسية إن كانت ظاهرة.
4) أهم مسارات الإشارة بين القطع (مثل: Tuner الى Demodulator الى CPU، أو الذاكرة الى المعالج).

اكتب الرد JSON فقط، بدون أي شرح خارجه وبدون علامات markdown، بالشكل التالي بالضبط:
{
  "components": [
    {"id": "U1", "name": "اسم القطعة أو الرقم المكتوب عليها", "type": "ic|cap|coil|diode|transistor|resistor|connector|regulator|crystal|fuse|other", "box": [x, y, w, h], "desc": "وظيفتها باختصار بالعربي"}
  ],
  "connections": [
    {"from": "id", "to": "id", "kind": "power|ground|signal", "label": "مثلا 12V او 5V او 3.3V او CLK", "certain": true, "path": [[x, y], [x, y]]}
  ],
  "notes": "ملخص بالعربي: مسار الكهرباء خطوة بخطوة، وأي أعطال محتملة ظاهرة (انتفاخ مكثف، حرق، لحام ضعيف)، وماذا يجب قياسه."
}

قواعد مهمة:
- كل الإحداثيات نسبية من 0 إلى 1 بالنسبة لأبعاد الصورة. box هو [x, y, العرض, الارتفاع] والنقطة (x,y) هي الركن العلوي الأيسر.
- path اختياري: نقاط تقريبية يمر بها المسار على البوردة بين القطعتين (يمكن تركه فارغا).
- لا تخترع قطعا غير ظاهرة. إذا لم تكن متأكدا من توصيلة اجعل certain = false.
- اذكر في notes بوضوح أن هذا تحليل تقديري من الصورة وأن التأكيد يتم بالقياس بالأفوميتر.
"""

    fun analyze(apiKey: String, model: String, jpeg: ByteArray): String {
        val b64 = Base64.encodeToString(jpeg, Base64.NO_WRAP)

        val image = JSONObject()
            .put("type", "image")
            .put(
                "source", JSONObject()
                    .put("type", "base64")
                    .put("media_type", "image/jpeg")
                    .put("data", b64)
            )
        val text = JSONObject().put("type", "text").put("text", PROMPT)
        val msg = JSONObject()
            .put("role", "user")
            .put("content", JSONArray().put(image).put(text))
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 4000)
            .put("messages", JSONArray().put(msg))

        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 30000
            conn.readTimeout = 180000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            conn.setRequestProperty("x-api-key", apiKey)
            conn.setRequestProperty("anthropic-version", "2023-06-01")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val resp = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IOException("HTTP " + code + ": " + resp.take(400))

            val arr = JSONObject(resp).getJSONArray("content")
            val sb = StringBuilder()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.optString("type") == "text") sb.append(o.optString("text"))
            }
            return sb.toString()
        } finally {
            conn.disconnect()
        }
    }
}
